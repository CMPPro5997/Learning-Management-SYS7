from django.contrib.auth import get_user_model
from django.shortcuts import get_object_or_404
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from courses.models import Course
from courses.serializers import CourseSerializer
from .models import Enrollment

User = get_user_model()


class StudentEnrollmentView(APIView):
    def get(self, request):
        username = request.query_params.get("student")

        if not username:
            return Response(
                {"error": "Student username is required."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        student = get_object_or_404(User, username=username)

        enrolled_course_ids = Enrollment.objects.filter(
            student=student
        ).values_list("course_id", flat=True)

        enrolled_courses = Course.objects.filter(
            id__in=enrolled_course_ids
        )

        available_courses = Course.objects.exclude(
            id__in=enrolled_course_ids
        )

        return Response(
            {
                "enrolled_courses": CourseSerializer(
                    enrolled_courses,
                    many=True,
                ).data,
                "available_courses": CourseSerializer(
                    available_courses,
                    many=True,
                ).data,
            }
        )

    def post(self, request):
        username = request.data.get("student")
        course_id = request.data.get("course")

        if not username or not course_id:
            return Response(
                {
                    "error": "Student username and course ID are required."
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        student = get_object_or_404(User, username=username)
        course = get_object_or_404(Course, id=course_id)

        enrollment, created = Enrollment.objects.get_or_create(
            student=student,
            course=course,
        )

        if not created:
            return Response(
                {"message": "Already enrolled."},
                status=status.HTTP_200_OK,
            )

        return Response(
            {"message": "Enrolment successful."},
            status=status.HTTP_201_CREATED,
        )