from django.urls import path
from .views import StudentEnrollmentView

urlpatterns = [
path("", StudentEnrollmentView.as_view(), name="student-enrolments"),
]