from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/", include("courses.urls")),
    path("api/enrollments/", include("enrollments.urls")),

    # Student login and logout routes
    path("accounts/", include("django.contrib.auth.urls")),
]