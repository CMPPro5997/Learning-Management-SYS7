from rest_framework import generics

from enrollments.models import Enrollment
from .models import Course
from .serializers import CourseSerializer


class CourseList(generics.ListCreateAPIView):
    serializer_class = CourseSerializer

    def get_queryset(self):
        username = self.request.query_params.get("student")

        if not username:
            return Course.objects.all()

        course_ids = Enrollment.objects.filter(
            student__username=username
        ).values_list("course_id", flat=True)

        return Course.objects.filter(id__in=course_ids)

    from rest_framework import generics
from .models import Course
from .serializers import CourseSerializer


class CourseDetail(generics.RetrieveAPIView):
    queryset = Course.objects.all()
    serializer_class = CourseSerializer