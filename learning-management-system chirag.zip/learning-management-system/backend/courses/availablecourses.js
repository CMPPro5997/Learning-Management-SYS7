import React, { useEffect, useState } from "react";

function AvailableCourses() {
  const [courses, setCourses] = useState([]);

  useEffect(() => {
    fetch("http://127.0.0.1:8000/api/courses/")
      .then((res) => res.json())
      .then((data) => setCourses(data));
  }, []);

  const enroll = (courseId) => {
    fetch("http://127.0.0.1:8000/api/enrollments/", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        student: 2, // student1 user id
        course: courseId,
      }),
    })
      .then(() => alert("Enrolled successfully"))
      .catch((err) => console.error(err));
  };

  return (
    <div>
      <h2>Available Courses</h2>

      {courses.map((course) => (
        <div key={course.id}>
          <h3>{course.title}</h3>
          <p>{course.description}</p>

          <button onClick={() => enroll(course.id)}>
            Enrol
          </button>
        </div>
      ))}
    </div>
  );
}

export default AvailableCourses;