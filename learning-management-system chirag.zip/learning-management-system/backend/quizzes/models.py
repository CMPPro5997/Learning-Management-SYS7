from django.db import models

# Create your models here.
from django.db import models
from courses.models import Course


class Quiz(models.Model):
    course = models.ForeignKey(
        Course,
        on_delete=models.CASCADE
    )
    title = models.CharField(max_length=200)

    def __str__(self):
        return self.title