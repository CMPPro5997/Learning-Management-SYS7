import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

function CourseDetail() {
  const { id } = useParams();
  const [course, setCourse] = useState(null);

  useEffect(() => {
    fetch(`http://127.0.0.1:8000/api/courses/${id}/`)
      .then((response) => response.json())
      .then((data) => setCourse(data))
      .catch((error) => console.error(error));
  }, [id]);

  if (!course) {
    return <p>Loading...</p>;
  }

  return (
    <div style={{ padding: "30px" }}>
      <h1>{course.title}</h1>

      <p>{course.description}</p>

      <h3>Lessons</h3>
      <p>Coming soon...</p>

      <h3>Quizzes</h3>
      <p>Coming soon...</p>
    </div>
  );
}

export default CourseDetail;