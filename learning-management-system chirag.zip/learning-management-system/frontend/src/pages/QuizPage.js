import React from "react";

function QuizPage() {
  return (
    <div style={{ padding: "30px" }}>
      <h1>Human Anatomy Quiz</h1>

      <p>
        1. Which system provides support for the body?
      </p>

      <div>
        <input type="radio" name="q1" />
        Skeletal System
      </div>

      <div>
        <input type="radio" name="q1" />
        Digestive System
      </div>

      <div>
        <input type="radio" name="q1" />
        Respiratory System
      </div>

      <br />

      <button>Submit Quiz</button>
    </div>
  );
}

export default QuizPage;