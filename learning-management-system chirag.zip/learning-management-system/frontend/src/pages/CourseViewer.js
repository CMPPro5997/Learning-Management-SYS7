import React from "react";

function CourseViewer() {
  return (
    <div style={{ padding: "30px" }}>
      <h1>Biology - Human Anatomy</h1>

      <h2>Lessons</h2>

      <ul>
        <li>Introduction to Human Anatomy</li>
        <li>Skeletal System</li>
        <li>Muscular System</li>
        <li>Nervous System</li>
      </ul>
    </div>
  );
}

export default CourseViewer;