import React from "react";

function Login() {
  return (
    <div>
      <h1>Learning Management System</h1>

      <h2>Student Login</h2>

      <form>
        <div>
          <label>Username</label>
          <input
            type="text"
            placeholder="Enter username"
          />
        </div>

        <br />

        <div>
          <label>Password</label>
          <input
            type="password"
            placeholder="Enter password"
          />
        </div>

        <br />

        <button type="submit">
          Login
        </button>
      </form>

      <p>Test User: student1</p>
    </div>
  );
}

export default Login;