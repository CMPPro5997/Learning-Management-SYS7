import React, {
  useCallback,
  useEffect,
  useState,
} from "react";
import { Link } from "react-router-dom";

const API_URL =
  "http://127.0.0.1:8000/api/enrollments/";

function Dashboard() {
  const [enrolledCourses, setEnrolledCourses] = useState([]);
  const [availableCourses, setAvailableCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [enrollingId, setEnrollingId] = useState(null);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const loadCourses = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      const response = await fetch(
        `${API_URL}?student=student1`
      );

      if (!response.ok) {
        throw new Error("Unable to load courses.");
      }

      const data = await response.json();

      setEnrolledCourses(data.enrolled_courses || []);
      setAvailableCourses(data.available_courses || []);
    } catch (requestError) {
      console.error("Error:", requestError);
      setError("Courses could not be loaded.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadCourses();
  }, [loadCourses]);

  const enrolCourse = async (courseId) => {
    setEnrollingId(courseId);
    setMessage("");
    setError("");

    try {
      const response = await fetch(API_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          student: "student1",
          course: courseId,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.error || "Enrolment failed."
        );
      }

      setMessage(data.message);
      await loadCourses();
    } catch (requestError) {
      console.error("Error:", requestError);
      setError(requestError.message);
    } finally {
      setEnrollingId(null);
    }
  };

  if (loading) {
    return (
      <main style={{ padding: "30px" }}>
        <p>Loading courses...</p>
      </main>
    );
  }

  return (
    <main style={{ padding: "30px", maxWidth: "800px" }}>
      <h1>Student Dashboard</h1>
      <h2>Welcome student1</h2>

      {message && (
        <p style={{ color: "green" }}>
          {message}
        </p>
      )}

      {error && (
        <p style={{ color: "red" }}>
          {error}
        </p>
      )}

      <section>
        <h3>My Courses</h3>

        {enrolledCourses.length === 0 ? (
          <p>You are not enrolled in any courses.</p>
        ) : (
          <ul>
            {enrolledCourses.map((course) => (
              <li key={course.id}>
                <Link to={`/course/${course.id}`}>
                  {course.title}
                </Link>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section style={{ marginTop: "30px" }}>
        <h3>Available Courses</h3>

        {availableCourses.length === 0 ? (
          <p>No additional courses are available.</p>
        ) : (
          availableCourses.map((course) => (
            <div
              key={course.id}
              style={{
                border: "1px solid #ccc",
                padding: "15px",
                marginBottom: "10px",
                borderRadius: "8px",
              }}
            >
              <h4>{course.title}</h4>
              <p>{course.description}</p>

              <button
                onClick={() =>
                  enrolCourse(course.id)
                }
                disabled={
                  enrollingId === course.id
                }
              >
                {enrollingId === course.id
                  ? "Enrolling..."
                  : "Enrol"}
              </button>
            </div>
          ))
        )}
      </section>
    </main>
  );
}

export default Dashboard;