import React from "react";

function LessonViewer() {
  return (
    <div style={{ padding: "30px" }}>
      <h1>Introduction to Human Anatomy</h1>

      <p>
        Human anatomy is the study of the structure of the
        human body and the relationships between body parts.
      </p>

      <h2>Learning Objectives</h2>

      <ul>
        <li>Understand what anatomy is</li>
        <li>Identify major body systems</li>
        <li>Understand body organisation</li>
      </ul>

      <button>Previous Lesson</button>

      <button style={{ marginLeft: "10px" }}>
        Next Lesson
      </button>
    </div>
  );
}

export default LessonViewer;